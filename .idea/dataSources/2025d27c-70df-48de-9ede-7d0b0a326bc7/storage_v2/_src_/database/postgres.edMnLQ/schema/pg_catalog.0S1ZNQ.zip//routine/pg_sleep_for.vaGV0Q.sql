create function pg_sleep_for(interval) returns void
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function pg_sleep_for(interval) owner to postgres;

