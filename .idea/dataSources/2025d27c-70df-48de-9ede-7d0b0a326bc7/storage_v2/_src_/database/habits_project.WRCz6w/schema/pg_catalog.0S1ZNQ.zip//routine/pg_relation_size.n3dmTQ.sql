create function pg_relation_size(regclass) returns bigint
    strict
    parallel safe
    cost 1
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function pg_relation_size(regclass) owner to postgres;

