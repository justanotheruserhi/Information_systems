create function obj_description(oid) returns text
    stable
    strict
    parallel safe
    language sql
as
$$
    begin
-- missing source code
end;
$$;

alter function obj_description(oid) owner to postgres;

